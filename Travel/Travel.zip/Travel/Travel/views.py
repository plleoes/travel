# Create your views here.

# from django.utils.translation import ugettext_lazy as _

from django.http import HttpResponse
from django.template import loader

from django.shortcuts import render

import os


def my_view_index(request):
    return render(request,'Index.html')


def my_view_registrationta(request):
    return render(request,'RegistrationTA.html')

def my_view_registrationto(request):
    return render(request,'RegistrationTO.html')

def my_view_regto(request):
    return render(request,'Index.html')

def my_view_regta(request):
    return render(request,'Index.html')
